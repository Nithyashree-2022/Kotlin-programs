data class Milk(var day:String,var choice:String,var sugar:Int)
{
    var water:Int?=null
    var status1:String?=null

    constructor(day:String,choice:String,sugar:Int,water:Int,status1:String):this(day,choice,sugar)
    {
        this.water=water
        this.status1=status1
    }

    var milk:Int?=null
    var status2:String?=null
    var flavour:String?=null
    var flavour_qty:Int?=null

    constructor(day:String,choice:String,sugar:Int,milk:Int,status2:String,flavour:String,flavour_qty:Int):this(day,choice,sugar)
    {
        this.milk=milk
        this.status2=status2
        this.flavour=flavour
        this.flavour_qty=flavour_qty
    }



}