fun main()
{
    val R=Robot("Amber Sharma")
    R.ringAlarm()
    R.makeMilk()
    R.heatWater()
    R.packMyBag()
    R.cookFood()
    R.dressMeUp()
}