data class Alarm(var day:String)
{
    var time:String?=null
    constructor(day: String,time:String):this(day)
    {
        this.time=time
    }
}