data class Packing(var day:String,var sub1:String,var sub2:String,var sub3:String,var sub4:String)
{
    var sub5:String?=null
    var sub6:String?=null

    constructor(day:String,sub1:String,sub2:String,sub3:String,sub4:String,sub5:String,sub6:String):this(day,sub1,sub2,sub3,sub4)
    {
        this.sub5=sub5
        this.sub6=sub6

    }


    var rackets:Int?=null
    constructor(day:String,sub1:String,sub2:String,sub3:String,sub4:String,rackets:Int):this(day,sub1,sub2,sub3,sub4)
    {
        this.rackets=rackets
    }


}
