import java.util.*

data class Food(var day:String)
{
    val breakfast_items=listOf("Chapatti","Paratha","Noodles","Pongal","Cornflakes","Idli & vada")

    val rice_list=listOf("Lemon rice","Pulav","Sambar rice","Curd rice","Fried rice")
    val curry_list=listOf("Carrot","Beetroot","Cabbage","Beans","Greens","Potato")
    val dessert_list=listOf("Kesari bath","Buttermilk","Rosemilk","Payasam","Pickle","Sonpapdi","Halwa","Samosa","Fingerchips")
}