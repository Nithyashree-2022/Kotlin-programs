data class Robot(var name:String)
{

    fun ringAlarm()
    {
        println("RING THE ALARM!!!")
        val A1=Alarm("Monday","5:00")
        val A2=Alarm("Tuesday","5:30")
        val A5=Alarm("Friday","6:00")
        val A7=Alarm("Sunday")
        val A6=Alarm("Saturday")
        val A3=Alarm("Wednesday","5:45")
        val A4=Alarm("Thursday","5:30")

        println("Hi boss!Your good robo,${name} is here to wake u up.I follow the schedule to help you get ready for college:")
        val Alist=mutableListOf(A1,A2,A3,A4,A5,A6,A7)
        for(i in 0 until Alist.size)
        {
            if(Alist[i].time!=null)
                println("${Alist[i].day}->${Alist[i].time}")
            else
                println("${Alist[i].day}->Dont worry,its your holiday today.So,I wont disturb you!Sleep well!!!")

        }

    }

    fun makeMilk()
    {

        val C1=Milk("Monday","Milk",1,1,"hot","Boost",2)
        val C2=Milk("Tuesday","Black coffee",2,1,"cold")
        val C3=Milk("Wednesday","Milk",3,1,"cold","Bornvita",2)
        val C4=Milk("Thursday","Milk",2,1,"hot","Dry fruit flavour",3)
        val C5=Milk("Friday","Black Coffee",1,1,"hot")

        val Clist= arrayListOf(C1,C2,C3,C4,C5)
        println("")
        println("")
        println("")
        println("PREPARE A GLASS OF MILK/BLACK COFFEE")

        println("Hi boss!Your good robo,${name} is here to help you enjoy your daily milk!I follow the schedule to help you get ready for college:")

        for(i in 0 until Clist.size)
        {
            if(Clist[i].choice=="Milk")
                println("${Clist[i].day}->${Clist[i].choice} with ${Clist[i].flavour}")
            else
                println("${Clist[i].day}->${Clist[i].choice}")

        }
    }

    fun heatWater()
    {

        val B1=Bath(10,0.5,0.5,"Monday",3)
        val B2=Bath(15,0.5,0.5,"Tuesday",0.7,"Mediker",0.3)
        val B3=Bath(5,0.4,0.6,"Wednesday")
        val B4=Bath(12,0.2,0.5,"Thursday",2,0.46,"Sunsilk",0.64)
        val B5=Bath(7,0.2,0.8,"Friday",5)
        val Blist=arrayListOf(B1,B2,B3,B4,B5)
        println("")
        println("")
        println("")
        println("TAKE BATH")
        println("Hi boss!Your good robo,${name} is here to help you prepare for your bath!I follow the schedule to help you get ready for college:")
        for(i in 0 until Blist.size)
        {
            println("Your schedule for ${Blist[i].day} is:")
            println("Heat the geyser for ${Blist[i].heat_time} minutes")
            println("Fill the bath bucket as:${Blist[i].hot_qty} of the bucket with hot water and ${Blist[i].cold_qty} of the bucket with cold water")
            if(Blist[i].eucalyptus!=null)
                println("Add ${Blist[i].eucalyptus} spoons of eucalyptus oil to the bath water")
            if(Blist[i].shampoo_qty!=null)
                println("Mix ${Blist[i].shampoo_qty} of the bowl with ${Blist[i].shampoo_brand} and the remaining ${Blist[i].frac_water} of the bowl with water")
            if(Blist[i].e!=null)
                println("Add ${Blist[i].e} spoons of eucalyptus oil to the bath water and mix ${Blist[i].sq} of the bowl with ${Blist[i].sb} and the remaining ${Blist[i].fw} of the bowl with water")
            println("")
            println("")
            println("")
        }
    }

    fun packMyBag()
    {

        val P1=Packing("Monday","Math","DAA","OS","MP",4)
        val P2=Packing("Tuesday","CO","FAFL","DAA","ADA Lab","ADA Lab","Math")
        val P3=Packing("Wednesday","MP","Math","MP Lab","MP Lab",6)
        val P4=Packing("Thursday","OS Lab","OS Lab","Python","DAA")
        val P5=Packing("Friday","OS","Math","DAA","Economics",2)
        val Plist=arrayListOf(P1,P2,P3,P4,P5)
        println("")
        println("")
        println("")
        println("PACK YOUR BAG")
        println("Hi boss!Your good robo,${name} is here to help you pack your bag!I follow the schedule to help you get ready for college:")
        for(i in 0 until Plist.size)
        {
            println("Your schedule for ${Plist[i].day} is:")
            println("List of classes:${Plist[i].sub1},${Plist[i].sub2},${Plist[i].sub3},${Plist[i].sub4}")
            if(Plist[i].sub5!=null && Plist[i].sub6!=null)
                println("Extra classes list:${Plist[i].sub5},${Plist[i].sub6}")
            if(Plist[i].rackets!=null)
                println("I will pack ${Plist[i].rackets} rackets for you today.")
            println("")
            println("")
        }

    }
    fun cookFood()
    {

        val F1=Food("Monday")
        val F2=Food("Tuesday")
        val F3=Food("Wednesday")
        val F4=Food("Thursday")
        val F5=Food("Friday")

        val Foodlist=arrayListOf(F1,F2,F3,F4,F5)
        println("")
        println("")
        println("")
        println("EAT WELL AND STAY FIT!!")

        println("Hi boss!Your good robo,${name} is here to cook tasty food items for you.I follow the schedule to help you get ready for college:")

        for(i in 0 until Foodlist.size) {
            println("Day:${Foodlist[i].day}")
            println("Breakfast:${Foodlist[i].breakfast_items.random()}")
            println("Lunch Plans:${Foodlist[i].rice_list.random()} with ${Foodlist[i].curry_list.random()} curry and ${Foodlist[i].dessert_list.random()} for a delightful dessert! ")
            println("")
            println("")}

    }
    fun dressMeUp()
    {

        val D1=Dress("Monday","Red","Jeans","White","Gold",'Y',"Shoes")
        val D2=Dress("Tuesday","Blue","Salwar","Green","Gold",'N')
        val D3=Dress("Wednesday","Brown","Jeans","Red","Silver",'Y',"Shoes")
        val D4=Dress("Thursday","Green","Salwar","White","Ring",'N',"Shoes")
        val D5=Dress("Friday","Grey","Pink","Green","Gold",'N')

        val Dresslist=arrayListOf(D1,D2,D3,D4,D5)
        println("")
        println("")
        println("")
        println("CLOTHES!")
        println("Hi boss!Your good robo,${name} is here to iron ur clothes daily!I follow the schedule to help you get ready for college:")
        println("I will iron your clothes according to the following schedule as follows:")
        for(i in 0 until Dresslist.size)
        {
            println("${Dresslist[i]} and ${Dresslist[i].footwear}")
            println("")
            println("")
        }

    }
}