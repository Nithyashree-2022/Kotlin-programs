data class Dress(var day:String,var top:String,var bottom:String,var dupatta:String,var earings:String,var watch:Char)
{
    var footwear:String?="Slippers"
    
    constructor(day:String,top:String,bottom:String,dupatta:String,earings:String,watch:Char,footwear:String):this(day,top,bottom,dupatta,earings,watch)
    {
        this.footwear=footwear
    }

}