data class Bath(var heat_time:Int,var hot_qty:Double,var cold_qty:Double,var day:String)
{


    var eucalyptus:Int?=null
    constructor(heat_time:Int,hot_qty:Double,cold_qty:Double,day:String,eucalyptus:Int):this(heat_time,hot_qty,cold_qty,day)
    {
        this.eucalyptus=eucalyptus

    }


    var shampoo_qty:Double?=null
    var shampoo_brand:String?=null
    var frac_water:Double?=null
    constructor(heat_time:Int,hot_qty:Double,cold_qty:Double,day:String,shampoo_qty:Double,shampoo_brand:String,frac_water:Double):this(heat_time,hot_qty,cold_qty,day)
    {
        this.shampoo_qty=shampoo_qty
        this.shampoo_brand=shampoo_brand
        this.frac_water=frac_water

    }


    var e:Int?=null
    var sq:Double?=null
    var sb:String?=null
    var fw:Double?=null
    constructor(heat_time:Int,hot_qty:Double,cold_qty:Double,day:String,e:Int,sq:Double,sb:String,fw:Double):this(heat_time,hot_qty,cold_qty,day)
    {
        this.e=e
        this.sq=sq
        this.sb=sb
        this.fw=fw

    }

}